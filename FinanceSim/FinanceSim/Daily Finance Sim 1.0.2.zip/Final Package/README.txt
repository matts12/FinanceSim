*********************
Daily Finance Sim
Version 1.0.2
Made by Matt Spooner 2016
Questions or feedback? Email matt.spooner10@gmail.com
Last Updated : 6/5/16
*********************

There are no requirements for this program other than the .exe itself.

Enter in profile data, and simulate.